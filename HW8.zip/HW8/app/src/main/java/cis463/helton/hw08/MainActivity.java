package cis463.helton.hw05;

//Example of starting activities
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;


public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
		//Setup parallel arrays for title and image
        String[] attraction={"Alcatraz Island", "Ferry Marketplace", "Golden Gate Bridge", "Cable Car Trolley", "Fisherman's Wharf"};
        int[] icon = {R.drawable.alcatraz_icon, R.drawable.marketplace_icon, R.drawable.bridge_icon, R.drawable.trolley_icon, R.drawable.wharf_icon};
		
		//Setup listview
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(new MyListAdapter(this, R.layout.activity_main, R.layout.items, attraction, icon));
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
              //  Toast.makeText(MainActivity.this, "Clicked item", Toast.LENGTH_LONG).show();
			  
			  //Switch based on selection
                switch(position)
                {
                    case 0:startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://alcatrazcruises.com/")));
                        break;
                    case 1:startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://ferrybuildingmarketplace.com")));
                        break;
                    case 2:startActivity(new Intent(MainActivity.this, Bridge.class));
                        break;
                    case 3: startActivity(new Intent(MainActivity.this, Trolley.class));
                        break;
                    case 4: startActivity(new Intent(MainActivity.this, Wharf.class));
                }

            }
        });

    }
}
