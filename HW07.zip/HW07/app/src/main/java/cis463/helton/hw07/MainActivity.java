package cis463.helton.hw07;


// The purpose of this app is to stream mp3 players from online
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;


public class MainActivity extends ActionBarActivity {
	
	
	//Setup Media Players, including parallel arrays for url and tilte
    MediaPlayer mediaPlayer = new MediaPlayer();
    String[] url = {"http://radio.classicalarchives.com:8000/;stream.nsv",
                    "http://2453.live.streamtheworld.com:80/KYGOFM_SC",
                    "http://vprbbc.streamguys.net:80/vprbbc24.mp3"};
    String[] title = {"Classical Radio",
                      "Country KYGO Denver, CO",
                       "BBC = Vermont Public Radio"};
	
	//Variables to track which stream is playing
    int playing = -1;
    int clicked = -1;
	
    Button btnClassical = null;
    Button btnCountry = null;
    ImageButton btnBbc = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnClassical = (Button) findViewById(R.id.btnClassic);
        btnClassical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked = 0;
                beginPlay(clicked);

            }
        });
        btnCountry = (Button) findViewById(R.id.btnCountry);
        btnCountry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked = 1;
                beginPlay(clicked);
            }
        });
        btnBbc = (ImageButton) findViewById(R.id.btnBBC);
        btnBbc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked = 2;
                beginPlay(clicked);
            }
        });

        mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                mp.reset();
                return false;
            }
        });

        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.start();
                Toast.makeText(MainActivity.this, "Streaming "+title[playing], Toast.LENGTH_LONG).show();
            }
        });

        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        Toast.makeText(MainActivity.this,"mediaPlayer created!", Toast.LENGTH_SHORT).show();
    }

	//Play selected stream
    private void beginPlay(int clicked)
    {
        if(clicked==playing)
        {
			//If stream is already playing, pause stream
            if(mediaPlayer.isPlaying())
            {
                mediaPlayer.pause();
                Toast.makeText(MainActivity.this, "Paused", Toast.LENGTH_LONG).show();
            }
			//Restart stream if it was already playing
            else
                mediaPlayer.start();
        }
        else
        {
            if(playing != -1)
            {
                if(mediaPlayer.isPlaying())
                    mediaPlayer.pause();
                mediaPlayer.reset();
            }
        }
		
		
		//Make a toast (Pop-up) message to display status of media player
        try {
            mediaPlayer.setDataSource(this, Uri.parse(url[clicked]));
            Toast.makeText(MainActivity.this, "setDataSource OK for mediaPlayer!", Toast.LENGTH_SHORT).show();

            mediaPlayer.prepareAsync();
            Toast.makeText(MainActivity.this, "Preparing mediaPlayer!", Toast.LENGTH_SHORT).show();


            }
			
			//Catch Exception, output to screen
        catch (Exception o){
            Toast.makeText(MainActivity.this, "IOException on mediaPlayer: " + 0, Toast.LENGTH_LONG).show();
        }
		
		//Set playing to clicked item
        playing = clicked;
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        if(mediaPlayer != null)
        {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    public void onPause()
    {
        super.onPause();
        if(mediaPlayer != null)
            mediaPlayer.release();
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();
        if(mediaPlayer != null)
            mediaPlayer.release();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
