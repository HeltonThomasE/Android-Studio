package cis463.helton.hw05;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Origamito1 on 2/22/2015.
 */
public class Trolley extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.trolley);

    }
}
